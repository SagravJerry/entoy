<?php
	header("content-type: application/vmd.ms-word");
	header("content-disposition attachment: filename=2019-25643VargaJerryBSIT-2C");
?>