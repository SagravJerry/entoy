<!DOCTYPE html>
<html>
<head>
	<title>Arithmetic Operation Program</title>
</head>
<style>
  body{
    margin:30px ;

  }
   a {
    display:block;
  }
  .btn{
    display:inline;
  }fieldset{
    display:inline-block;
    height:500px;


  }
  fieldset:nth-child(1){
    width:1255px;
    display: block;
    height:100px;
    margin-bottom: 20px;
  }

  .hit{
    border:1px solid black;
    margin:10px;
    background:none;
    padding:10px;
    height: 50px;
    width:200px;
    background-color:#66ccff;
  }.hit2{
    height: 50px;
  }
  .shell h1{
    justify-content: center;
    align-items: center;
    text-align: center;
  }


  }
</style>
<body>
	<div class="shell">
  <fieldset> 
	<h1>Arithmetic Operation Program</h1>
  </fieldset> 
	
    <fieldset>
      <a href="add.ph.php"target="var"><button class="hit">Addition</button></a>
      <a href="subtraction.php"target="var"><button class="hit">Subtraction</button></a>
      <a href="multiplication.php"target="var"><button class="hit">Multiplication</button></a>
      <a href="division.php"target="var"><button class="hit">Division</button></a>
      <a href="area1.php"target="var"><button class="hit hit2">Area and Perimeter of Triangle</button></a>
      <a href="area2.php"target="var"><button class="hit hit2">Area and Perimeter of Rectangle</button></a>
    </fieldset>
    <fieldset>
      <iframe src="" height="500" width="900" name="var" id="var" ></iframe>
    </fieldset>
  </div>
    

</body>
</html>`